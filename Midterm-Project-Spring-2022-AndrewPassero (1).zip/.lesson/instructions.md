# Instructions  

Carefully read the instructions posted in Moodle in the Google doc and the colab.